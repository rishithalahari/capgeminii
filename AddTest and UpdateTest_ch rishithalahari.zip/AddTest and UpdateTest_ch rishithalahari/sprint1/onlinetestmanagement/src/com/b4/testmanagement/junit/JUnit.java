package com.b4.testmanagement.junit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.b4.testmanagement.dao.TestDao;
import com.b4.testmanagement.dao.TestDaoImpl;
import com.b4.testmanagement.dto.Testt;

public class JUnit {
      TestDao dao=null;
      @Before
      public void setUp()
      {
    	  dao=new TestDaoImpl();
    	  
      }
      @After
      public void tearDown()
      {
    	  dao=null;
      }
		@Test
		public void testAddTest() 
		{
			TestDao dao = new TestDaoImpl();
			Testt a =new Testt(103,"JAVA","one hour",100);
			int rows = dao.addTest(a);
			Assert.assertEquals(rows,1);
		
		}
		@Test
		public void testNegativeAddTest() 
		{
			TestDao dao = new TestDaoImpl();
			Testt a =new Testt(103,"JAVA","one hour",100);
			int rows = dao.addTest(a);
			Assert.assertNotEquals(rows,2);
		}
		
		@Test
		public void testUpdateTest() {
			TestDao dao = new TestDaoImpl();
			Testt a =new Testt(103,"MPT","one hour",100);
			int rows = dao.addTest(a);
			Assert.assertEquals(rows,1);
		}


		@Test
		public void testNegativeUpdateTest() {
			TestDao dao = new TestDaoImpl();
			Testt a =new Testt(103,"MPT","one hour",100);
			int rows = dao.addTest(a);
			Assert.assertNotEquals(rows,2);
		}

	}