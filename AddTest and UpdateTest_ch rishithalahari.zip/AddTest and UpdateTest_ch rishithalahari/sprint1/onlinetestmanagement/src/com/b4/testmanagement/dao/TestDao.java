package com.b4.testmanagement.dao;

import com.b4.testmanagement.dto.Testt;

public interface TestDao 
{
		public void openConnection();
		public void close();
		public int addTest(Testt test);
		public int updateTest(Testt test);
		
}
