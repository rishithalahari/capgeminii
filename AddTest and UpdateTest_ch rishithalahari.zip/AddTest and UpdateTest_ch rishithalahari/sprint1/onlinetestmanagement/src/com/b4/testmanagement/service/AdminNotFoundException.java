package com.b4.testmanagement.service;

@SuppressWarnings("serial")
public class AdminNotFoundException extends Exception{
	
		
		public AdminNotFoundException()
		{
		      super("Invalid for user");
		}
		}




