package com.b4.testmanagement.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.b4.testmanagement.dto.Testt;
import com.b4.testmanagement.utils.TestDBQueries;

	public class TestDaoImpl implements TestDao 
	{

	private Connection connection=null;
	private PreparedStatement pst;
	private ResultSet result;

	@Override
	public void openConnection()
	{
	try
	{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	connection = DriverManager.getConnection(url,"scott","tiger");
	}
	catch(ClassNotFoundException | SQLException e)
	{
	e.printStackTrace();
	}
	}
	@Override
	public void close()
	{
	try{
	connection.close();
	}
	catch(SQLException e)
	{
	e.printStackTrace();
	}
	}
	@Override
	public int addTest(Testt test)
	{
	openConnection();
	int rows=0;
	try{
	pst=connection.prepareStatement(TestDBQueries.addTestQuery);
	pst.setInt(1, test.getTestid());
	pst.setString(2,test.getTestTitle());
	pst.setString(3, test.getTestDuration());
	pst.setInt(4, test.getTestTotalMarks());
	
	
	rows=pst.executeUpdate();
	}
	catch(SQLException e)
	{
	e.printStackTrace();
	}
	close();
	return rows;
	}
	@Override
	public int updateTest(Testt test)
	{
		openConnection();
		int rows=0;
		try{
		pst=connection.prepareStatement(TestDBQueries.updateTestQuery);
		pst.setInt(4, test.getTestid());
		pst.setString(1,test.getTestTitle());
		pst.setString(2, test.getTestDuration());
		pst.setInt(3, test.getTestTotalMarks());
		rows=pst.executeUpdate();
		}
		catch(SQLException e)
		{
		e.printStackTrace();
		}
		close();
		return rows;
		}
	}