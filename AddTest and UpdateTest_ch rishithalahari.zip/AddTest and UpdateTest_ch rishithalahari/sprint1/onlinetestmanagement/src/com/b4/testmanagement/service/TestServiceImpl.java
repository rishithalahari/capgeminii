package com.b4.testmanagement.service;

import com.b4.testmanagement.dao.TestDao;
import com.b4.testmanagement.dao.TestDaoImpl;
import com.b4.testmanagement.dto.Testt;


public  class TestServiceImpl implements TestService
{

	TestDao dao=new TestDaoImpl();
	@Override
	public int addTest(Testt test)
	{
	int rows=dao.addTest(test);
	return rows;
	}
	@Override
	public int updateTest(Testt test) 
	{
	int rows=dao.updateTest(test);
	return rows;
	}
	
}

