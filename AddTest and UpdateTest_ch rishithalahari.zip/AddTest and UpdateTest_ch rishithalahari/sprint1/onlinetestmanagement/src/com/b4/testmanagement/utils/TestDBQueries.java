package com.b4.testmanagement.utils;

public class TestDBQueries 
{	
	public static String addTestQuery="insert into test values(?,?,?,?)";
	public static String updateTestQuery = " update test set testTitle=?,testDuration=?,testTotalMarks=? where testid=?";
}

