package com.b4.testmanagement.application;

import com.b4.testmanagement.dto.Testt;
import com.b4.testmanagement.service.TestService;
import com.b4.testmanagement.service.TestServiceImpl;

public class AddTest 
{
	public static void main(String[] args)
	{
		Testt test=new Testt(102,"one hour","GK",100);
		TestService ser=new TestServiceImpl();
		int rows=ser.updateTest(test);
		if(rows>0)
		System.out.println("updated");
		else
		System.out.println("not updated");
		}

		
}