package com.b4.testmanagement.presentation;

import java.util.Scanner;

import com.b4.testmanagement.dto.Testt;
import com.b4.testmanagement.service.AdminNotFoundException;
import com.b4.testmanagement.service.TestService;
import com.b4.testmanagement.service.TestServiceImpl;


	public class TestMain{
		
		
		public static void main(String[] args) {
	Scanner a = new Scanner(System.in);
		while(true)
		{
			System.out.println("1.Admin");
			System.out.println("2.User");
			int opt = a.nextInt();
			switch(opt)
			{
			
			case 1:
	{
	Scanner sc1 = new Scanner(System.in);
	System.out.println("enter the options\n1.add\n2.update");
    int input = sc1.nextInt();
    if(input==1)
    {
    	Testt tes =new Testt(102,"MPT","one hour",100);
		TestService ser=new TestServiceImpl();
		int rows=ser.addTest(tes);
		if(rows>0)
		System.out.println("added");
		else
		System.out.println("not added");
    }
    else if(input==2) {
	 Testt t1=new Testt(102,"one hour","GK",100);
	TestService ser=new TestServiceImpl();
	int rows=ser.updateTest(t1);
	if(rows>0)
	System.out.println("updated");
	else
	System.out.println("not updated");
    }
		 break;
	}
		
			case 2:
			
				
				if(opt==2)
			
					try{		
		
		
		throw new AdminNotFoundException();
		}
		        catch(AdminNotFoundException e)
		{
		        System.out.println(e.getMessage());
		}
		
		}
	
		
		}
		}
	}
	
	