package com.b4.testmanagement.service;

import com.b4.testmanagement.dto.Testt;

public interface TestService 
{
		public int addTest(Testt test);
		public int updateTest(Testt test);
		
		

}
